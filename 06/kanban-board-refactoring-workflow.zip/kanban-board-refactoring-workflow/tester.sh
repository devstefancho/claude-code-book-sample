claude --agent chrome-tester " \
  아래 Workflow로 진행한다. \
  1. 서버 background task로 실행해줘 \
  2. 프로젝트 소스코드 분석하고, 테스트 항목들 보여줘 \
  3. 유저가 선택한 테스트를 Chrome MCP로 진행해줘 \
"
