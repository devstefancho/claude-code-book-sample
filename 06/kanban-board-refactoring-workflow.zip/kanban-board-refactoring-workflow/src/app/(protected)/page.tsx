import { KanbanBoard } from "@/components/board/KanbanBoard";

export default function Home() {
  return <KanbanBoard />;
}
