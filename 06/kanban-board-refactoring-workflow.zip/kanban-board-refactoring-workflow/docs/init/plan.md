# 칸반 보드 기술 구현 계획서

## 원본 기술 스택 요청사항

```
frontend는 Nextjs, dnd-kit, Tailwindcss를 사용하고 안정적인 버전을 선택하도록 한다.
상태 관리는 localStorage를 활용한다.
backend와 배포는 이번 작업에서는 구현하지 않는다.
```

**추가 기술 결정:**

- Tailwind CSS 3.4 (안정 버전 선택)
- Zustand (상태 관리 라이브러리)
- Zod (데이터 검증)
- 60%+ 테스트 커버리지 목표

---

## 기술 스택

### 프론트엔드 프레임워크

- **Next.js** (v15.5): 최신 안정 버전으로 Turbopack을 활용한 빠른 빌드, App Router를 통한 현대적인 라우팅 아키텍처 제공. 클라이언트 측 Kanban 보드에 최적화된 성능 최적화 기능 포함

### UI 프레임워크

- **React** (v19): Next.js 15.5에 포함된 버전. 동시성 기능과 향상된 성능 제공

### 스타일링

- **Tailwind CSS** (v3.4): 검증된 안정 버전으로 생태계 호환성 우수. JIT 엔진으로 빠른 빌드 제공. v4보다 서드파티 라이브러리 지원이 안정적이며, 프로덕션 환경에서 검증됨

### 언어

- **TypeScript** (v5.7+): 타입 안전성 제공으로 대규모 프로젝트에 적합. 개발자 경험 향상 및 컴파일 타임 에러 감지

### 상태 관리

- **Zustand** (v5.0+): 경량(1KB) 상태 관리 라이브러리. persist 미들웨어를 통한 자동 localStorage 동기화 지원. Redux 대비 보일러플레이트 최소화, Context API 대비 우수한 성능과 개발자 경험 제공

### 핵심 라이브러리

#### 드래그 앤 드롭

- **@dnd-kit/core** (v6.3.1): 경량(~10KB), 접근성 우선, 키보드 네비게이션 기본 지원
- **@dnd-kit/sortable** (v9.0.0): 컬럼 내 카드 재정렬 기능
- **@dnd-kit/utilities** (v3.2.2): 헬퍼 함수 제공

#### 데이터 검증

- **Zod** (v3.24+): 런타임 타입 검증으로 localStorage 데이터 무결성 보장. TypeScript와 완벽한 통합으로 타입 안전성 강화

#### 유틸리티

- **nanoid** (v5.1+): 고유 ID 생성 (118 bytes, uuid 대비 경량). URL-friendly하며 보안성 우수
- **clsx** (v2.1+): 조건부 Tailwind 클래스 결합을 위한 경량 유틸리티

### 개발 도구

#### 린팅 및 포맷팅

- **ESLint** (v9.x): 코드 품질 검사
- **eslint-config-next**: Next.js 권장 규칙
- **Prettier** (v3.4+): 코드 포맷팅 (ESLint와 독립적으로 실행하여 성능 향상)

#### 테스트

- **Jest** (v29.x): 테스트 프레임워크
- **@testing-library/react** (v16.x): React 19 지원, 사용자 중심 테스트
- **@testing-library/jest-dom**: DOM 매처 확장
- **@testing-library/user-event**: 실제 사용자 인터랙션 시뮬레이션
- **jest-axe**: 자동 접근성 테스트

#### 코드 품질

- **Husky**: Git 훅 관리
- **lint-staged**: 스테이징된 파일에만 린터 실행

### 패키지 매니저

- **npm**: Node.js 기본 패키지 매니저 사용 (프로젝트 규모상 충분)

---

## 아키텍처 개요

### 시스템 설계

- **애플리케이션 타입**: SPA (Single Page Application)
- **아키텍처 패턴**: 컴포넌트 기반 + 기능별 분리 (Feature-based)
- **렌더링 전략**: CSR (Client-Side Rendering) - 모든 상태가 클라이언트에서 관리되며 localStorage 사용

### 디렉토리 구조

```
kanban-board/
├── src/
│   ├── app/                        # Next.js App Router
│   │   ├── layout.tsx              # 루트 레이아웃 (메타데이터, 전역 스타일)
│   │   ├── page.tsx                # 메인 Kanban 보드 페이지
│   │   └── globals.css             # Tailwind imports
│   ├── components/                 # React 컴포넌트
│   │   ├── board/                  # 보드 관련 컴포넌트
│   │   │   ├── KanbanBoard.tsx     # 보드 컨테이너 (DndContext)
│   │   │   ├── Column.tsx          # 컬럼 컴포넌트 (드롭 영역)
│   │   │   ├── Card.tsx            # 카드 컴포넌트 (드래그 가능)
│   │   │   └── ColumnHeader.tsx    # 컬럼 헤더 (제목, 카운트)
│   │   ├── modals/                 # 모달 컴포넌트
│   │   │   ├── CardFormModal.tsx   # 카드 생성/수정 통합 모달
│   │   │   └── ConfirmModal.tsx    # 삭제 확인 모달
│   │   └── ui/                     # 재사용 가능한 UI 컴포넌트
│   │       ├── Button.tsx          # 버튼 컴포넌트
│   │       ├── Input.tsx           # 입력 필드
│   │       ├── Textarea.tsx        # 텍스트 영역
│   │       └── Modal.tsx           # 모달 베이스 컴포넌트
│   ├── lib/                        # 유틸리티 및 헬퍼
│   │   ├── store.ts                # Zustand 스토어 정의
│   │   ├── validation.ts           # Zod 스키마 정의
│   │   └── constants.ts            # 상수 (컬럼 정의, 제한값 등)
│   ├── types/                      # TypeScript 타입 정의
│   │   └── index.ts                # Card, Column, Status, KanbanState 타입
│   └── hooks/                      # 커스텀 React 훅
│       └── useKanbanStore.ts       # Zustand 스토어 훅 래퍼
├── __tests__/                      # 테스트 파일
│   ├── unit/                       # 단위 테스트
│   │   ├── store.test.ts           # 상태 관리 로직 테스트
│   │   └── validation.test.ts      # 검증 로직 테스트
│   ├── integration/                # 통합 테스트
│   │   ├── card-crud.test.tsx      # 카드 CRUD 테스트
│   │   └── drag-drop.test.tsx      # 드래그 앤 드롭 테스트
│   └── utils/                      # 테스트 유틸리티
│       └── test-utils.tsx          # RTL 커스텀 렌더러
├── public/                         # 정적 자산
├── .eslintrc.json                  # ESLint 설정
├── .prettierrc                     # Prettier 설정
├── jest.config.ts                  # Jest 설정
├── jest.setup.ts                   # Jest 셋업 (테스트 환경 구성)
├── next.config.js                  # Next.js 설정
├── tailwind.config.ts              # Tailwind 설정
├── tsconfig.json                   # TypeScript 설정
└── package.json                    # 의존성 관리
```

### 컴포넌트 계층 구조

```
App (page.tsx)
└── KanbanBoard
    ├── Column (할 일)
    │   ├── ColumnHeader
    │   └── Card[] (드래그 가능)
    ├── Column (진행 중)
    │   ├── ColumnHeader
    │   └── Card[]
    ├── Column (완료)
    │   ├── ColumnHeader
    │   └── Card[]
    ├── CardFormModal (생성/수정)
    └── ConfirmModal (삭제 확인)
```

### 데이터 흐름

1. **사용자 액션** → UI 컴포넌트 이벤트
2. **이벤트 핸들러** → Zustand 스토어 액션 호출
3. **스토어 업데이트** → Immer 기반 불변 상태 업데이트
4. **Persist 미들웨어** → 자동으로 localStorage에 저장
5. **상태 변경** → React 리렌더링 트리거
6. **UI 업데이트** → 최신 상태 반영

### 설계 패턴

- **Container/Presentational 패턴**: 비즈니스 로직과 UI 분리
- **커스텀 훅 패턴**: 로직 재사용 및 테스트 용이성
- **Compound Component 패턴**: Modal, Card 등 복잡한 UI 컴포넌트 구조화
- **Optimistic UI 업데이트**: 드래그 앤 드롭 시 즉각적인 피드백

---

## 데이터 모델

### 엔티티 정의

```typescript
// types/index.ts

/**
 * 카드 상태 (컬럼 타입)
 */
export type CardStatus = "todo" | "in-progress" | "done";

/**
 * 카드 엔티티
 */
export interface Card {
  id: string; // nanoid로 생성된 고유 ID
  title: string; // 제목 (필수, 1-200자)
  description: string; // 설명 (선택, 0-2000자)
  status: CardStatus; // 현재 상태 (컬럼)
  order: number; // 컬럼 내 순서 (0부터 시작)
  createdAt: number; // 생성 시각 (Unix timestamp)
  updatedAt: number; // 수정 시각 (Unix timestamp)
}

/**
 * 컬럼 정의
 */
export interface Column {
  id: CardStatus; // 컬럼 고유 ID (status와 동일)
  title: string; // 컬럼 제목 (한글)
  cards: Card[]; // 컬럼에 속한 카드 배열 (order로 정렬)
}

/**
 * 전역 Kanban 상태
 */
export interface KanbanState {
  columns: Record<CardStatus, Column>; // 3개 컬럼 (todo, in-progress, done)

  // 액션
  addCard: (card: Omit<Card, "id" | "createdAt" | "updatedAt" | "order">) => void;
  updateCard: (id: string, updates: Partial<Pick<Card, "title" | "description">>) => void;
  deleteCard: (id: string) => void;
  moveCard: (cardId: string, targetStatus: CardStatus, targetOrder: number) => void;
  reorderCard: (cardId: string, newOrder: number) => void;
}
```

### 데이터 관계

- 각 **Column**은 여러 **Card**를 포함 (1:N)
- **Card**는 하나의 **Column**에만 속함 (N:1)
- **Card.status**와 **Column.id**로 관계 매핑
- **Card.order**로 동일 컬럼 내 순서 관리

### 저장소 전략

#### 주요 저장소

- **localStorage**: 유일한 영속성 계층
- **키**: `kanban-store` (Zustand persist 기본값)
- **포맷**: JSON 직렬화

#### 데이터 검증

- **Zod 스키마**: 로드 시 데이터 구조 검증
- **실패 처리**: 손상된 데이터 감지 시 빈 초기 상태로 복원
- **마이그레이션**: 버전 필드 추가로 향후 스키마 변경 대응

#### 캐싱 전략

- **메모리 캐싱**: Zustand가 메모리에 상태 유지
- **localStorage 동기화**: 모든 상태 변경 시 자동 저장
- **지연 없음**: 동기 API 사용 (5MB 제한 내에서 충분히 빠름)

### 상태 구조 (State Shape)

```typescript
// 실제 localStorage에 저장되는 구조
{
  "state": {
    "columns": {
      "todo": {
        "id": "todo",
        "title": "할 일",
        "cards": [
          {
            "id": "abc123xyz",
            "title": "첫 번째 카드",
            "description": "상세 설명",
            "status": "todo",
            "order": 0,
            "createdAt": 1704067200000,
            "updatedAt": 1704067200000
          }
        ]
      },
      "in-progress": {
        "id": "in-progress",
        "title": "진행 중",
        "cards": []
      },
      "done": {
        "id": "done",
        "title": "완료",
        "cards": []
      }
    }
  },
  "version": 0  // persist 버전
}
```

---

## API 설계

**해당 없음** - 순수 클라이언트 측 애플리케이션

이번 반복에서는 백엔드를 구현하지 않으며, 모든 데이터는 localStorage를 통해 관리됩니다.

향후 멀티 유저 또는 클라우드 동기화 기능 추가 시 다음과 같은 API 설계 고려:

- RESTful API: `/api/cards`, `/api/columns`
- WebSocket: 실시간 동기화
- 인증: JWT 기반 사용자 인증

현재는 **로컬 우선 아키텍처**로 설계되었습니다.

---

## 컴포넌트 구조

### 핵심 컴포넌트

```
KanbanBoard (보드 루트)
├── Column × 3 (할 일, 진행 중, 완료)
│   ├── ColumnHeader
│   │   ├── 컬럼 제목
│   │   └── 카드 개수 뱃지
│   └── Card[] (드래그 가능)
│       ├── 카드 제목
│       ├── 카드 설명 (일부)
│       └── 액션 버튼 (수정, 삭제)
└── 모달
    ├── CardFormModal (생성/수정)
    │   ├── Input (제목)
    │   ├── Textarea (설명)
    │   └── Button (저장/취소)
    └── ConfirmModal (삭제 확인)
        └── Button (확인/취소)
```

### 컴포넌트 책임

#### **KanbanBoard.tsx**

- **역할**: DnD 컨텍스트 제공, 전체 보드 레이아웃
- **Props**: 없음 (Zustand에서 상태 가져옴)
- **상태**: 모달 열림/닫힘, 선택된 카드 ID
- **책임**:
  - `DndContext` 설정 (sensors, collision detection)
  - 드래그 종료 시 `moveCard` 또는 `reorderCard` 호출
  - 3개 컬럼 렌더링
  - 카드 생성 버튼 제공

#### **Column.tsx**

- **역할**: 드롭 영역, 카드 리스트 렌더링
- **Props**: `column: Column`
- **상태**: 없음 (stateless)
- **책임**:
  - `useDroppable` 훅으로 드롭 영역 설정
  - `SortableContext`로 정렬 가능 영역 제공
  - 카드를 `order`로 정렬하여 렌더링

#### **Card.tsx**

- **역할**: 드래그 가능 카드 UI
- **Props**: `card: Card`, `onEdit: () => void`, `onDelete: () => void`
- **상태**: 없음
- **책임**:
  - `useSortable` 훅으로 드래그 가능 설정
  - 카드 제목, 설명 표시 (설명은 100자 제한하여 표시)
  - 수정/삭제 버튼 렌더링
  - 드래그 중 시각적 피드백 (opacity, transform)

#### **ColumnHeader.tsx**

- **역할**: 컬럼 제목과 카드 개수 표시
- **Props**: `title: string`, `count: number`
- **상태**: 없음
- **책임**:
  - 컬럼 제목 렌더링
  - 카드 개수 뱃지 표시

#### **CardFormModal.tsx**

- **역할**: 카드 생성/수정 폼
- **Props**: `mode: 'create' | 'edit'`, `card?: Card`, `onClose: () => void`
- **상태**: 폼 데이터 (title, description), 검증 에러
- **책임**:
  - 제목 입력 (필수, 200자 제한)
  - 설명 입력 (선택, 2000자 제한)
  - Zod 검증 실행
  - 저장 시 `addCard` 또는 `updateCard` 호출

#### **ConfirmModal.tsx**

- **역할**: 삭제 확인 다이얼로그
- **Props**: `title: string`, `message: string`, `onConfirm: () => void`, `onCancel: () => void`
- **상태**: 없음
- **책임**:
  - 경고 메시지 표시
  - 확인/취소 버튼 제공
  - ESC 키로 취소 가능

### 컴포지션 전략

- **Props drilling 최소화**: Zustand 훅으로 필요한 곳에서 직접 상태 접근
- **이벤트 핸들러 전달**: 부모에서 자식으로 콜백 전달 (onEdit, onDelete)
- **Compound Components**: Modal 내부에서 Header, Body, Footer 조합

### 재사용성 패턴

- **UI 컴포넌트 추상화**: Button, Input, Textarea, Modal은 완전히 재사용 가능
- **비즈니스 로직 분리**: 컴포넌트는 UI만 담당, 로직은 Zustand 스토어에
- **타입 안전성**: 모든 컴포넌트에 명시적 TypeScript 인터페이스

### 스타일링 접근법

- **방법**: Tailwind CSS 유틸리티 클래스
- **테마**: CSS 변수로 색상 정의 (다크모드 대응 가능하도록 설계)
- **반응형 디자인**:
  - **Mobile**: 320px~ (단일 컬럼 세로 스택)
  - **Tablet**: 768px~ (3컬럼 가로 배치, 좁은 카드)
  - **Desktop**: 1024px~ (3컬럼 넓은 카드)

```typescript
// Tailwind 반응형 예시
<div className="flex flex-col md:flex-row gap-4">
  {/* Mobile: 세로 스택, Tablet+: 가로 배치 */}
</div>
```

---

## 상태 관리

### 상태 아키텍처

#### 전역 상태 (Zustand)

- **컬럼 데이터**: 모든 컬럼과 카드
- **CRUD 액션**: addCard, updateCard, deleteCard, moveCard, reorderCard

#### 로컬 상태 (useState)

- **모달 상태**: 열림/닫힘, 모드 (create/edit)
- **폼 데이터**: 임시 입력값 (저장 전까지)
- **UI 상태**: 드래그 중 오버레이, 로딩 스피너

#### 서버 상태

- **해당 없음**: 백엔드가 없으므로 서버 상태 없음

### 상태 관리 라이브러리

**Zustand 선택 이유**:

1. **경량**: 1KB (Redux는 ~10KB)
2. **간단한 API**: 보일러플레이트 최소화
3. **Persist 미들웨어**: localStorage 자동 동기화
4. **TypeScript 친화적**: 타입 추론 우수
5. **DevTools 지원**: Redux DevTools 호환

### 데이터 흐름

```
사용자 액션 (드래그 종료)
    ↓
이벤트 핸들러 (handleDragEnd)
    ↓
Zustand 액션 호출 (moveCard)
    ↓
Immer 기반 상태 업데이트 (불변성 유지)
    ↓
Persist 미들웨어 → localStorage 저장
    ↓
구독 컴포넌트 리렌더링
    ↓
UI 업데이트 (카드 이동 반영)
```

### 상태 연산 (CRUD)

#### Create (카드 생성)

```typescript
addCard: (card) =>
  set((state) => {
    const newCard = {
      ...card,
      id: nanoid(),
      order: state.columns[card.status].cards.length,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    state.columns[card.status].cards.push(newCard);
    // Immer가 불변성 자동 처리
  });
```

#### Read (카드 조회)

```typescript
// 컴포넌트에서 직접 선택
const cards = useKanbanStore((state) => state.columns["todo"].cards);
```

#### Update (카드 수정)

```typescript
updateCard: (id, updates) =>
  set((state) => {
    // 모든 컬럼에서 카드 찾기
    for (const column of Object.values(state.columns)) {
      const card = column.cards.find((c) => c.id === id);
      if (card) {
        Object.assign(card, updates, { updatedAt: Date.now() });
        break;
      }
    }
  });
```

#### Delete (카드 삭제)

```typescript
deleteCard: (id) =>
  set((state) => {
    for (const column of Object.values(state.columns)) {
      const index = column.cards.findIndex((c) => c.id === id);
      if (index !== -1) {
        column.cards.splice(index, 1);
        // order 재정렬
        column.cards.forEach((card, idx) => (card.order = idx));
        break;
      }
    }
  });
```

### 부수 효과 (Side Effects)

#### 비동기 작업

- **해당 없음**: localStorage는 동기 API
- 향후 API 통합 시 async 액션 추가

#### 에러 처리

```typescript
// localStorage 쓰기 실패 처리
try {
  localStorage.setItem("kanban-store", JSON.stringify(state));
} catch (e) {
  if (e.name === "QuotaExceededError") {
    alert("저장 공간이 부족합니다. 일부 카드를 삭제해주세요.");
  }
}
```

#### Optimistic 업데이트

- 드래그 앤 드롭 시 즉시 UI 업데이트
- localStorage 저장 실패 시에도 롤백 없음 (로컬 우선)

---

## 보안 고려사항

### 입력 검증

#### 클라이언트 측 검증

- **Zod 스키마**:
  ```typescript
  const cardSchema = z.object({
    title: z.string().min(1, "제목을 입력하세요").max(200, "제목은 200자 이내"),
    description: z.string().max(2000, "설명은 2000자 이내"),
  });
  ```
- **실시간 검증**: onChange 이벤트에서 검증 실행
- **UI 피드백**: 에러 메시지 빨간색으로 표시

#### 서버 측 검증

- **해당 없음**: 백엔드가 없음
- 향후 API 추가 시 동일한 Zod 스키마 재사용 가능

#### 새니타이제이션 (Sanitization)

- **XSS 방지**: React가 기본적으로 이스케이프 처리
- **dangerouslySetInnerHTML 금지**: 사용하지 않음
- **외부 입력 검증**: 모든 사용자 입력을 Zod로 검증

### 데이터 보호

#### 민감 데이터

- **해당 없음**: 개인 식별 정보 없음, 로컬 Kanban 보드만
- 향후 멀티 유저 버전 시 고려사항:
  - 사용자 인증 정보 암호화
  - HTTPS 강제

#### 저장소 보안

- **localStorage**: 평문 저장 (브라우저 보안에 의존)
- **암호화 불필요**: 민감 정보 없음
- **도메인 격리**: Same-Origin Policy로 다른 사이트 접근 불가

#### HTTPS

- **개발 환경**: HTTP (localhost)
- **프로덕션**: HTTPS 강제 (Vercel/Netlify 기본 제공)

### 일반적인 취약점 대응

#### XSS 방지

- **React 자동 이스케이프**: `{card.title}` 자동 안전 처리
- **innerHTML 금지**: Markdown 파싱 등 사용하지 않음
- **CSP 헤더**: (배포 시 설정 권장)

#### CSRF 보호

- **해당 없음**: 백엔드 API 없음
- 향후 API 추가 시 CSRF 토큰 구현

#### SQL Injection

- **해당 없음**: 데이터베이스 없음

### 인증 및 권한 부여

**현재 버전**:

- 단일 사용자, 클라이언트 측 전용
- 인증 불필요

**향후 고려사항** (멀티 유저 버전):

- **인증 전략**: JWT 기반 토큰 인증
- **보호된 라우트**: Next.js middleware로 인증 체크
- **권한 관리**: RBAC (Role-Based Access Control) - 카드 소유자만 수정/삭제

### 보안 헤더

**개발 환경**: 설정 없음

**프로덕션 권장 설정** (next.config.js):

```javascript
async headers() {
  return [
    {
      source: '/:path*',
      headers: [
        {
          key: 'X-Frame-Options',
          value: 'DENY',
        },
        {
          key: 'X-Content-Type-Options',
          value: 'nosniff',
        },
        {
          key: 'Referrer-Policy',
          value: 'strict-origin-when-cross-origin',
        },
      ],
    },
  ];
}
```

---

## 테스트 전략

### 테스트 프레임워크

- **단위 테스트**: Jest + @testing-library/react
- **통합 테스트**: Jest + @testing-library/react + @testing-library/user-event
- **E2E 테스트**: 이번 반복에서는 제외 (향후 Playwright 고려)

### 테스트 커버리지 목표

- **전체 목표**: 60%+ (핵심 기능 집중)
- **단위 테스트**: 상태 관리 로직, 검증 함수, 유틸리티
- **통합 테스트**: 카드 CRUD, 드래그 앤 드롭 플로우

### 테스트 대상

#### 컴포넌트 테스트

- **Card 컴포넌트**: 제목/설명 렌더링, 버튼 클릭 이벤트
- **Column 컴포넌트**: 카드 리스트 렌더링, 빈 상태 처리
- **Modal 컴포넌트**: 열림/닫힘, ESC 키 동작

#### 상태 관리 테스트

- **addCard**: 카드 생성, order 자동 할당, timestamp 생성
- **updateCard**: 제목/설명 수정, updatedAt 갱신
- **deleteCard**: 카드 삭제, order 재정렬
- **moveCard**: 컬럼 간 이동, status 변경

#### 유틸리티 테스트

- **Zod 검증**: 유효한 입력, 최대 길이 초과, 필수 필드 누락

#### API 통합 테스트

- **해당 없음**: 백엔드 없음

### 테스트 패턴

```typescript
// 예시: Card 컴포넌트 단위 테스트
describe('Card', () => {
  it('카드 제목과 설명을 렌더링한다', () => {
    const card = {
      id: '1',
      title: '테스트 카드',
      description: '설명',
      status: 'todo' as const,
      order: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    render(<Card card={card} onEdit={jest.fn()} onDelete={jest.fn()} />);

    expect(screen.getByText('테스트 카드')).toBeInTheDocument();
    expect(screen.getByText('설명')).toBeInTheDocument();
  });

  it('수정 버튼 클릭 시 onEdit 콜백을 호출한다', async () => {
    const onEdit = jest.fn();
    const card = { /* ... */ };

    render(<Card card={card} onEdit={onEdit} onDelete={jest.fn()} />);

    await userEvent.click(screen.getByRole('button', { name: /수정/i }));

    expect(onEdit).toHaveBeenCalledTimes(1);
  });
});

// 예시: 드래그 앤 드롭 통합 테스트 (모킹 필요)
describe('Drag and Drop', () => {
  it('카드를 다른 컬럼으로 이동한다', async () => {
    // dnd-kit 센서 모킹
    // 드래그 시작 → 드래그 종료 시뮬레이션
    // 카드가 새 컬럼에 나타나는지 확인
  });
});
```

### CI/CD 통합

#### CI 파이프라인

- **GitHub Actions** (권장):
  ```yaml
  name: CI
  on: [push, pull_request]
  jobs:
    test:
      runs-on: ubuntu-latest
      steps:
        - uses: actions/checkout@v3
        - uses: actions/setup-node@v3
        - run: npm ci
        - run: npm run lint
        - run: npm test -- --coverage
        - run: npm run build
  ```

#### Pre-commit 훅

- **Husky + lint-staged**:
  ```json
  {
    "*.{ts,tsx}": ["eslint --fix", "prettier --write"],
    "*.{json,md}": ["prettier --write"]
  }
  ```
- **실행 시점**: `git commit` 전 자동 실행
- **목적**: 커밋 전 코드 품질 보장

#### 테스트 자동화

- **로컬**: `npm test` (watch 모드)
- **CI**: PR 생성/푸시 시 자동 실행
- **커버리지 리포트**: GitHub Actions artifact로 저장

### 접근성 테스트

#### 도구

- **jest-axe**: 자동 WCAG 2.1 검사

  ```typescript
  import { axe, toHaveNoViolations } from 'jest-axe';

  expect.extend(toHaveNoViolations);

  it('접근성 위반이 없어야 한다', async () => {
    const { container } = render(<KanbanBoard />);
    const results = await axe(container);
    expect(results).toHaveNoViolations();
  });
  ```

- **eslint-plugin-jsx-a11y**: 정적 분석 (Next.js에 포함됨)

#### 수동 테스트

- **스크린 리더 테스트**: VoiceOver (macOS), NVDA (Windows)
- **키보드 네비게이션**: Tab, Enter, Escape, Arrow keys
- **색상 대비**: Chrome DevTools Lighthouse

#### WCAG 검증

- **목표**: Level AA 준수
- **자동 검사**: jest-axe
- **수동 검사**: Lighthouse 접근성 점수 90+

---

## 배포 계획

**이번 반복에서는 배포를 구현하지 않습니다.** 아래는 향후 배포 시 참고용 계획입니다.

### 빌드 프로세스

```bash
# 프로덕션 빌드
npm run build

# 로컬 프로덕션 테스트
npm run start
```

**빌드 출력**:

- `.next/` 폴더에 최적화된 정적 파일 생성
- 자동 코드 분할 (route-based)
- 이미지 최적화

### 환경 설정

#### 개발 환경 (Development)

- **실행**: `npm run dev`
- **포트**: 3000
- **Hot Reload**: 활성화
- **소스맵**: 활성화

#### 프로덕션 환경 (Production)

- **실행**: `npm run build && npm start`
- **최적화**:
  - Minification (HTML, CSS, JS)
  - Tree-shaking
  - 이미지 최적화
  - Gzip/Brotli 압축

### 환경 변수

```bash
# .env.local (gitignore에 추가)
NEXT_PUBLIC_APP_NAME="Kanban Board"
```

**참고**: 현재 버전에서는 환경 변수 불필요 (백엔드 API 없음)

### 호스팅 플랫폼

#### 권장: Vercel

- **이유**:
  - Next.js 개발사에서 제공 (최적 호환성)
  - 자동 HTTPS, CDN, 엣지 배포
  - GitHub 연동 자동 배포
  - 무료 티어 충분 (개인 프로젝트)

- **비용**: 무료 (Hobby 플랜)

#### 대안: Netlify

- Next.js 지원 우수
- 무료 티어 제공
- GitHub Actions로 배포 자동화

### 배포 단계

1. **GitHub 저장소 연결**
2. **Vercel 프로젝트 생성**
3. **빌드 설정**:
   - Framework: Next.js
   - Build Command: `npm run build`
   - Output Directory: `.next`
4. **배포 트리거**: `main` 브랜치 푸시 시 자동 배포
5. **프리뷰 배포**: PR 생성 시 자동 프리뷰 URL 생성

### CI/CD 파이프라인

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      # Vercel CLI로 배포 (또는 Vercel GitHub 앱 사용)
```

**트리거**: `main` 브랜치 푸시
**빌드**: 자동 테스트 및 빌드
**배포**: Vercel로 자동 배포

### 성능 최적화

#### 코드 분할 (Code Splitting)

- **Next.js 자동 분할**: 페이지별 자동 분할
- **동적 import**: 모달 컴포넌트 lazy loading
  ```typescript
  const CardFormModal = dynamic(() => import("@/components/modals/CardFormModal"));
  ```

#### 자산 최적화

- **이미지**: Next.js Image 컴포넌트 (현재 사용 안 함)
- **폰트**: 시스템 폰트 사용 (추가 로드 없음)
- **아이콘**: SVG 인라인 (외부 아이콘 라이브러리 미사용)

#### 캐싱 전략

- **브라우저 캐싱**: Vercel 자동 설정 (정적 자산 1년)
- **CDN**: Vercel Edge Network (전 세계 배포)
- **localStorage**: 영구 캐싱 (사용자 데이터)

#### 번들 크기

- **목표**: 초기 JS 번들 < 200KB (gzip)
- **모니터링**: `npm run build` 후 번들 분석
- **도구**: `@next/bundle-analyzer` (선택 사항)

### 모니터링

#### 에러 트래킹

- **현재**: 브라우저 콘솔
- **향후**: Sentry 통합 (무료 티어)

#### 애널리틱스

- **해당 없음**: 개인 프로젝트
- **향후**: Vercel Analytics 또는 Google Analytics

#### 성능 모니터링

- **Web Vitals**: Next.js 내장 지원
  ```typescript
  // pages/_app.tsx
  export function reportWebVitals(metric) {
    console.log(metric); // LCP, FID, CLS 등
  }
  ```
- **Lighthouse**: 수동 실행 (목표 90+ 점수)

---

## 의존성

### 프로덕션 의존성

```json
{
  "next": "^15.5.0", // Next.js 프레임워크
  "react": "^19.0.0", // React 라이브러리
  "react-dom": "^19.0.0", // React DOM 렌더러
  "@dnd-kit/core": "^6.3.1", // 드래그 앤 드롭 코어
  "@dnd-kit/sortable": "^9.0.0", // 정렬 가능 리스트
  "@dnd-kit/utilities": "^3.2.2", // DnD 유틸리티
  "zustand": "^5.0.2", // 상태 관리
  "zod": "^3.24.1", // 스키마 검증
  "nanoid": "^5.1.6", // 고유 ID 생성
  "clsx": "^2.1.1" // 클래스 이름 결합
}
```

### 개발 의존성

```json
{
  "typescript": "^5.7.2", // TypeScript 컴파일러
  "@types/node": "^22.10.2", // Node.js 타입 정의
  "@types/react": "^19.0.2", // React 타입 정의
  "@types/react-dom": "^19.0.2", // React DOM 타입 정의
  "tailwindcss": "^3.4.17", // Tailwind CSS 프레임워크
  "postcss": "^8.4.49", // CSS 후처리기
  "autoprefixer": "^10.4.20", // CSS 벤더 프리픽스
  "eslint": "^9.18.0", // 린터
  "eslint-config-next": "^15.5.0", // Next.js ESLint 설정
  "eslint-config-prettier": "^10.0.1", // Prettier와 충돌 방지
  "prettier": "^3.4.2", // 코드 포매터
  "jest": "^29.7.0", // 테스트 프레임워크
  "jest-environment-jsdom": "^29.7.0", // Jest DOM 환경
  "@testing-library/react": "^16.1.0", // React 테스팅 라이브러리
  "@testing-library/jest-dom": "^6.6.3", // Jest DOM 매처
  "@testing-library/user-event": "^14.5.2", // 사용자 이벤트 시뮬레이션
  "jest-axe": "^10.0.0", // 접근성 테스트
  "@types/jest": "^29.5.14", // Jest 타입 정의
  "ts-node": "^10.9.2", // TypeScript 실행기
  "husky": "^9.1.7", // Git 훅 관리
  "lint-staged": "^15.2.11" // 스테이징된 파일 린트
}
```

### 의존성 선택 근거

#### **@dnd-kit** vs react-beautiful-dnd

- **@dnd-kit 선택**:
  - 더 경량 (~10KB vs ~30KB)
  - 모던 훅 기반 API
  - 더 나은 접근성 지원
  - react-beautiful-dnd는 유지보수 중단됨

#### **Zustand** vs Redux vs Context API

- **Zustand 선택**:
  - Redux: 과도한 보일러플레이트, 작은 프로젝트에 과함
  - Context API: 수동 localStorage 동기화 필요, 성능 최적화 어려움
  - Zustand: 완벽한 균형 (경량, persist 내장, 간단한 API)

#### **Zod** vs Yup vs Joi

- **Zod 선택**:
  - TypeScript 우선 설계 (타입 추론 우수)
  - 런타임 + 컴파일 타임 검증
  - 작은 번들 크기
  - 최신 ECMAScript 지원

#### **nanoid** vs uuid

- **nanoid 선택**:
  - 훨씬 작음 (118 bytes vs 423 bytes)
  - URL-friendly (특수 문자 없음)
  - 동일한 충돌 확률
  - 더 빠른 생성 속도

#### **Tailwind CSS 3.4** vs 4.1

- **3.4 선택 (사용자 요청)**:
  - 안정적인 생태계
  - 서드파티 라이브러리 호환성 보장
  - 프로덕션 환경에서 검증됨
  - 충분히 빠른 빌드 속도

### 버전 전략

#### 주요 버전 업데이트

- **월 1회**: 의존성 업데이트 체크 (Dependabot 활용)
- **보안 패치**: 즉시 적용
- **메이저 버전**: 릴리스 노트 확인 후 신중히 업데이트

#### 보안 취약점 스캐닝

```bash
npm audit          # 취약점 검사
npm audit fix      # 자동 수정 (패치 버전)
```

#### Breaking Change 관리

- **package-lock.json**: 버전 고정으로 예측 가능한 빌드
- **Major 업데이트**: 별도 브랜치에서 테스트 후 병합
- **Migration Guide**: 공식 문서 참조

### 번들 크기 최적화

**현재 예상 번들 크기** (gzip 압축 후):

- **Next.js 런타임**: ~90KB
- **React + React DOM**: ~45KB
- **@dnd-kit**: ~10KB
- **Zustand**: ~1KB
- **Zod**: ~15KB
- **애플리케이션 코드**: ~30KB
- **총합**: ~190KB (목표 200KB 이하 달성)

---

## 요약

### 기술적 결정 요약

1. **Next.js 15.5 + React 19 + TypeScript 5.7**
   - 최신 프레임워크로 최고의 개발자 경험과 성능 제공
   - App Router로 모던 아키텍처 구현

2. **Tailwind CSS 3.4**
   - 안정적이고 검증된 버전으로 생태계 호환성 보장
   - 유틸리티 우선 접근법으로 빠른 개발

3. **@dnd-kit**
   - 경량, 접근성 우선, 키보드 지원
   - 스펙의 모든 DnD 요구사항 충족

4. **Zustand + Persist 미들웨어**
   - 자동 localStorage 동기화로 개발 간소화
   - Redux 대비 90% 적은 코드, 더 나은 DX

5. **Zod**
   - 런타임 데이터 검증으로 localStorage 무결성 보장
   - TypeScript 타입 안전성 강화

### 주요 기술적 트레이드오프

1. **Tailwind 3.4 vs 4.1**
   - **선택**: 3.4 (안정성 우선)
   - **장점**: 검증된 생태계, 호환성
   - **단점**: v4보다 빌드 속도 느림 (실용적으로는 문제 없음)

2. **Zustand vs Context API**
   - **선택**: Zustand (사용자 승인)
   - **장점**: persist 미들웨어, 더 나은 성능, 간결한 코드
   - **단점**: 외부 의존성 추가 (+1KB)

3. **60% vs 80% 테스트 커버리지**
   - **선택**: 60% (사용자 승인)
   - **장점**: 빠른 MVP 개발, 핵심 기능 집중
   - **단점**: 엣지 케이스 일부 미검증 (향후 추가 가능)

### 리스크 완화 전략

1. **성능 리스크** (100개 카드 + 60fps DnD):
   - React.memo로 불필요한 리렌더링 방지
   - CSS transform으로 GPU 가속 활용
   - 필요 시 virtualization 추가

2. **localStorage 제한**:
   - 100개 카드 ≈ 25KB (5MB 한도의 0.5%)
   - QuotaExceededError 핸들링 구현
   - 사용자에게 명확한 에러 메시지

3. **접근성 준수**:
   - jest-axe 자동 테스트
   - dnd-kit 내장 키보드 지원
   - ARIA 레이블 필수 적용

---

## 다음 단계

✅ **기술 구현 계획 완료**: `docs/init/plan.md`

### 📋 요약

- **기술 스택**: Next.js 15.5 + React 19 + TypeScript 5.7 + Tailwind 3.4
- **핵심 라이브러리**: @dnd-kit (DnD) + Zustand (상태) + Zod (검증)
- **아키텍처**: 클라이언트 전용 SPA, localStorage 기반
- **테스트**: Jest + RTL (60%+ 커버리지)
- **배포**: (이번 반복 제외)

### 💡 핵심 기술 결정

1. **Tailwind 3.4**: 안정성과 생태계 호환성 우선
2. **Zustand**: persist 미들웨어로 자동 localStorage 동기화
3. **Zod**: 데이터 무결성 보장 및 타입 안전성 강화
4. **60% 테스트**: 핵심 기능 집중, 빠른 MVP 개발

### 🚀 다음 단계

프로젝트 초기 설정 및 구현을 시작하려면:

1. **의존성 설치**: `npm install`로 모든 패키지 설치
2. **프로젝트 구조 생성**: 디렉토리 및 기본 파일 생성
3. **설정 파일 작성**: TypeScript, ESLint, Tailwind 설정
4. **핵심 구현**: 컴포넌트, 상태 관리, 스타일링
5. **테스트 작성**: 단위/통합 테스트 구현

상세한 구현 작업은 별도 태스크로 관리할 수 있습니다.
